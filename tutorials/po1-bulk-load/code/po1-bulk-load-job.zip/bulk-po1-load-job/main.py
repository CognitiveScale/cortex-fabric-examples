import io
import json
import sys
from itertools import chain

import pandas as pd
from cortex import Cortex
from cortex.content import ManagedContentClient
from cortex.serviceconnector import _Client as CortexClient
from cortex_common.types import DeclaredProfileAttribute, ObservedProfileAttribute, InferredProfileAttribute
from cortex_common.types import NumberAttributeValue, StringAttributeValue, EntityEvent
from cortex_profiles import ProfileBuilder


def eprint(*args, **kwargs):
    print(*args, file=sys.stderr, **kwargs)


def instantiate_clients(cortex_endpoint, cortex_jwt_token):
    cortex_v2_client = CortexClient(cortex_endpoint, 2, cortex_jwt_token)
    cortex_v3_client = Cortex().client(api_endpoint=cortex_endpoint, api_version=3, token=cortex_jwt_token)

    # Instantiate MC Client
    cortex_mc_client = ManagedContentClient(cortex_endpoint, 2, cortex_jwt_token)

    # Load Secret from Cortex Vault for Po1 Builder Client
    key_of_secret = "uri.po1-db"
    db_secret = cortex_v2_client._get_json(f"tenants/secrets/variables/{key_of_secret}").get("value")
    # Instantiate Po1 Builder Client
    po1_builder = ProfileBuilder(cortex_v3_client, bulk_mode=True, db_uri=db_secret).profiles()
    return cortex_v2_client, cortex_v3_client, cortex_mc_client, po1_builder


def download_data_for_po1_building(cortex_mc_client, key_of_csv_file_in_mc):
    content = cortex_mc_client.download(key_of_csv_file_in_mc, retries=2).read().decode('utf-8')
    return pd.read_csv(io.StringIO(content))


def extract_attribute_building_events_from_po1_data(po1_df):

    def plain_attribute_generator(df, pid_column, value_column, entity_type, attr_value_type):
        # Gotcha ... in a generator ... dont reference a variable that you re-assign ...
        # ... had to get the generator in a method for it to work ... since the function has seperate variables!
        return (
            EntityEvent(
                event=value_column,
                entityId=profileId,
                entityType=entity_type,
                properties=dict(
                    attr_value_type(value=attr_value)
                )
            )
            for (profileId, attr_value) in df[[pid_column, value_column]].itertuples(name=None, index=False)
        )

    declared_attribute_stream = chain(*[
        plain_attribute_generator(po1_df, pid_column, value_column, entity_type, attr_value_type)
        for (pid_column, value_column, entity_type, attr_value_type) in [
            ("profileId", "age", "cortex/person", NumberAttributeValue),
            ("profileId", "name", "cortex/person", StringAttributeValue),
        ]
    ])

    observed_attribute_stream = chain(*[
        plain_attribute_generator(po1_df, pid_column, value_column, entity_type, attr_value_type)
        for (pid_column, value_column, entity_type, attr_value_type) in [
            ("profileId", "total.likedRecommendations", "cortex/person", NumberAttributeValue),
            ("profileId", "total.abandonedRecommendations", "cortex/person", NumberAttributeValue),
            ("profileId", "total.viewedRecommendations", "cortex/person", NumberAttributeValue),
            ("profileId", "total.logins", "cortex/person", NumberAttributeValue),
        ]
    ])

    inferred_attribute_stream = (
            EntityEvent(
                event="predictedTotal.loginsNextWeek",
                entityId=profileId,
                entityType="cortex/person",
                properties=dict(
                    NumberAttributeValue(value=attr_value, weight=attr_value_weight)
                )
            )
            for (profileId, attr_value, attr_value_weight) in (
                po1_df[["profileId", "predictedTotal.loginsNextWeek", "predictedTotal.loginsNextWeek.confidence"]]
                    .itertuples(name=None, index=False)
            )
    )

    return declared_attribute_stream, observed_attribute_stream, inferred_attribute_stream


def main():
    try:
        eprint("Started Job ...")
        eprint("Sys Args: {}".format(sys.argv[1:]))
        container_params = json.loads(sys.argv[1])
        eprint("Arguments Job Received from Cortex: {}".format(json.dumps(container_params, indent=4)))
        cortex_v2_client, cortex_v3_client, cortex_mc_client, po1_builder = instantiate_clients(
            container_params["apiEndpoint"], container_params["token"]
        )
        key_of_po1_data_file = container_params["payload"]["key"]
        po1_df = download_data_for_po1_building(cortex_mc_client, key_of_po1_data_file)
        eprint(f"Downloaded po1 data from MC into a DF with Shape {po1_df.shape}.")
        limit = container_params["payload"].get("limit", -1)
        df = po1_df.head(limit) if limit > 0 else po1_df
        declared_attr_stream, observed_attr_stream, inferred_attr_stream = extract_attribute_building_events_from_po1_data(df)
        eprint(f"Created a streams of attribute building events.")
        (bulk_version_num, event_resp, attr_resp) = (
            po1_builder
                .with_events(declared_attr_stream, attributeType=DeclaredProfileAttribute)
                .with_events(observed_attr_stream, attributeType=ObservedProfileAttribute)
                .with_events(inferred_attr_stream, attributeType=InferredProfileAttribute)
                .build()
        )
        response = {
            "bulk_version_number": bulk_version_num,
            "event_bulk_insert_response": event_resp,
            "attribute_bulk_insert_response": attr_resp,
        }
        eprint("Job SUCCEEDED")
        print(json.dumps(response))
    except Exception as e:
        eprint(e)
        returnVal = {"payload": {"text": "Error!", "message": "{}".format(e)}}
        eprint("Job FAILED, Result: {}".format(json.dumps(returnVal, indent=4)))


if __name__ == "__main__":
    main()
